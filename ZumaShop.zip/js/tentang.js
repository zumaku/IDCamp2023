const aside = document.querySelector(".biodata")
const tombol = document.querySelector(".tombol")

tombol.addEventListener("click", () => {
    // if(aside.classList.contains("muncul")){

    // }
    aside.classList.toggle("muncul")
})